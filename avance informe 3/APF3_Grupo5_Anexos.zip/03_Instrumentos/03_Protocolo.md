# Protocolo de validación inclusiva APF3

Versión final ejecutada (03/11/2026 al 05/11/2026). Estado: 5 sesiones ejecutadas y validadas (AP3-01 a AP3-05) con 3 perfiles de accesibilidad. Responsable de campo: Emerson Junior Mendoza Ventura / Grupo 5.

## Selección y consentimiento
Convocar al menos cinco personas adultas y tres perfiles (visual, motor, cognitivo o experiencia digital). Al menos dos deben declarar una condición real relevante o uso habitual de una ayuda. No exigir diagnósticos, constancias ni simulaciones incómodas. Registrar ayuda, configuración y dispositivo preferidos. Permitir acompañante y descansos. Una simulación se etiqueta expresamente y no cuenta como persona real con condición o ayuda habitual.

Antes de iniciar: explicar objetivo, duración 30–40 min, voluntariedad, datos registrados, destinatarios, custodia y retirada. Usar el consentimiento separado. La grabación es opcional. Si no acepta participar, no ejecutar ni registrar tareas. Guardar identificadores de consentimiento en las hojas y el documento firmado en custodia restringida.

## Preparación
Ejecutar el prototipo web local y dejar la misma versión para toda la muestra. Probar el canal de guardado. Limpiar datos ficticios entre sesiones según el manual. Registrar versión, ancho, zoom real del navegador, orientación, lector y versión, fecha y navegador. No cambiar las preferencias de una persona sin acuerdo. No desactivar su tecnología habitual para comparar tiempos. Verificar acceso por teclado y realizar un ensayo interno, claramente separado de los participantes.

## Guion de apertura
Estamos evaluando el sitio, no tus capacidades. Puedes usar tu forma habitual de interacción, pedir una pausa o terminar. No te diremos dónde hacer clic. Cuéntanos qué intentas hacer si te resulta cómodo. Usaremos únicamente información ficticia en los formularios.

## Tareas sin pistas
T1 Localiza la metodología de Primaria y menciona dos características.
T2 Encuentra cómo contactar al colegio por una consulta de Primaria.
T3 Explica dónde indicarías el motivo de la consulta.
T4 Registra una consulta de demostración y recupera un error de correo. Usar el correo ficticio inicialmente mal formado `prueba@` y luego `prueba@example.com`, nombre ficticio y un mensaje inocuo. El cierre es revisar y confirmar, con código visible de registro.

Para T1–T3 conservar consignas y reglas del APF2. Para T4 dar el dato de prueba sin explicar qué campo o botón corrige el error. Iniciar tiempo al terminar la instrucción. Finalizar al completar, abandonar o alcanzar cinco minutos acordados. Registrar abandono y tiempo límite; no computarlo como tiempo de éxito. Ofrecer ayuda si la pide, anotar el momento y clasificar ASIS. No contar la lectura lenta, pausas pactadas ni uso de ayudas como errores.

## Registro y medidas
Por intento: código anónimo, tarea, versión, AUT/ASIS/F, tiempo en segundos, errores, SEQ, comentario literal y barrera. AUT significa completado sin ayuda del moderador; la ayuda técnica propia no es asistencia del moderador. SEQ: En general, ¿qué tan difícil o fácil te resultó esta tarea? Respuesta 1 muy difícil, 2, 3, 4, 5, 6, 7 muy fácil. Aplicar inmediatamente después de cada tarea, también tras un fallo si la persona desea responder.

Aplicar SUS al finalizar las tareas, con diez respuestas de 1 totalmente en desacuerdo a 5 totalmente de acuerdo. Cálculo: suma (impares menos 1) y (5 menos pares), multiplicada por 2,5. No imputar respuestas faltantes. Usar idéntica redacción a la del APF2 si el equipo conserva ese cuestionario; la redacción en español del formulario es una adaptación operativa y no se presenta como una traducción validada.

## Plan de análisis
Éxito autónomo: AUT / intentos válidos, con numerador y denominador por tarea y perfil. Separar ASIS y F. Tiempo: mediana entre completados, indicando n. Errores: conteo y descripción. SEQ: mediana por tarea y perfil. SUS: valores individuales y media con n completo. Si n es muy pequeño, no inferir diferencias poblacionales. Comparar T1–T3 con APF2 B (n=6, sin perfiles accesibles registrados); T4 y SEQ no tienen línea base. No usar diferencia pareada si cambian las personas. Metas propuestas: 80% AUT por tarea, ningún bloqueo por perfil, mediana SEQ≥5 y SUS≥75. Estas metas no acreditan conformidad AA.

## Cierre y barreras residuales
Preguntar qué fue difícil, qué preferiría cambiar y si desea retirar una observación. Agradecer sin calificar su desempeño. Vincular cada barrera residual a criterio, perfil, evidencia, responsable, fecha acordada y revalidación. Guardar solo lo necesario. Propuesta de retención: hasta cerrar la evaluación y el periodo de revisión docente, luego eliminar registros identificables y grabaciones. El equipo confirma por escrito plazo y responsable antes de recoger datos.

## Recorrido técnico complementario
En Figma ejecutar Stark para contraste y simulación visual, registrar versión y capturas propias. En la web, recorrer Tab/Mayús+Tab/Enter/Espacio/Escape, zoom NATIVO 200%, 320 px, ambas orientaciones, espaciado (1,5 línea, 2 párrafos, 0,12 letras, 0,16 palabras) y al menos un lector (NVDA+Chrome o VoiceOver+Safari según equipo real). Registrar mensajes escuchados literalmente. No llamar prueba realizada a una hoja de pasos preparada.
