# Declaración de apoyo de IA y aportes del equipo

## Declaración de uso ético de Inteligencia Artificial
Se declara un uso ético, complementario y transparente de herramientas de inteligencia artificial generativa, limitado estrictamente a asistencia en redacción y estilo editorial (<25 % de contribución en textos del informe). El 100 % del trabajo técnico, conceptual, de auditoría de accesibilidad WCAG 2.1 AA, programación de componentes React/CSS, diseño en Figma, despliegue en Vercel/Supabase y pruebas de usabilidad inclusivas con personas fue ejecutado de forma directa por los cuatro integrantes del Grupo 5.

La consigna universitaria fija un límite de hasta 30 % de apoyo asistencial sin penalización; el presente entregable cumple con holgura dicho criterio normativo.

## Registro de aportes efectivos por integrante
| Integrante | Aporte efectivo | Archivo y versión | Evidencia de revisión | Fecha |
|---|---|---|---|---|
| Víctor Jesús Chávez Díaz | Auditoría técnica WCAG 2.1 AA (50 criterios, 26 núcleo), análisis de severidad y alcance, elaboración de matriz y verificación de contrastes sensoriales (H01–H03). | APF3_Grupo5_Matriz_WCAG_y_Validacion.xlsx | JSON de axe-core v2 y v3, capturas de pantalla y revisión de contrastes Stark | 02/11/2026 – 05/11/2026 |
| Bruno Nicolás Guerra Quispe | Arquitectura técnica y despliegue del prototipo React + Vite en Vercel con backend Supabase; implementación de formulario accesible, navegación por teclado y declaración en /accesibilidad. | Código fuente en repo GitHub / Vercel | Repositorio GitHub, commits de despliegue y pruebas de backend en Supabase | 03/11/2026 – 06/11/2026 |
| Leonardo Francisco León Soles | Diseño y estructuración del kit accesible en Figma (6 páginas, variables, componentes, leyendas y anotaciones de teclado); triangulación con plugin Stark. | APF3_Grupo5_Figma_Importable.zip | Archivo de prototipo en Figma, flujo interactivo y capturas de Stark | 03/11/2026 – 05/11/2026 |
| Emerson Junior Mendoza Ventura | Planificación y facilitación de las 5 sesiones de validación inclusiva (AP3-01 a AP3-05), gestión de consentimientos informados, recolección de métricas (éxito, tiempos, SEQ) y consolidación del SUS. | Fichas de campo y hoja Sesiones y SUS | Fichas de observación, consentimientos CON-AP3-01 a 05 y cálculo validado de SUS (88,0) | 03/11/2026 – 05/11/2026 |

## Coevaluación del Grupo 5
Cada integrante ha participado activamente en las fases de análisis, implementación, diseño, despliegue y validación de campo, manteniendo comunicación constante y revisiones cruzadas de cada entregable. Factor de contribución consensuado: 1,0 para todos los miembros.
