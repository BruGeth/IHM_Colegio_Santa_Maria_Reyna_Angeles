# Declaración de Autoría y Aportes del Equipo - APF3

## Declaración de Autoría Académica
El análisis técnico de accesibilidad WCAG 2.1 AA, la matriz de 50 criterios, el código React/CSS, el kit interactivo de Figma de 6 páginas, el despliegue funcional en Vercel con Supabase y las pruebas de validación inclusiva con usuarios fueron desarrollados de manera íntegra, directa y colaborativa por los cuatro integrantes del Grupo 5.

## Registro de Aportes por Integrante
| Integrante | Aporte Técnico Efectivo | Entregable Asociado | Fecha |
|---|---|---|---|
| Víctor Jesús Chávez Díaz | Auditoría técnica WCAG 2.1 AA (50 criterios, 26 núcleo), análisis de severidad y alcance, elaboración de matriz y verificación de contrastes sensoriales (H01–H03). | Matriz WCAG y resumen de auditoría | 02/11/2026 – 05/11/2026 |
| Bruno Nicolás Guerra Quispe | Arquitectura técnica y despliegue del prototipo React + Vite en Vercel con backend Supabase; implementación de formulario accesible, navegación por teclado y declaración en `/accesibilidad`. | Prototipo web desplegado y repositorio | 03/11/2026 – 06/11/2026 |
| Leonardo Francisco León Soles | Diseño y estructuración del kit accesible en Figma (6 páginas, variables, componentes, leyendas y anotaciones de teclado); triangulación con plugin Stark. | Prototipo interactivo en Figma | 03/11/2026 – 05/11/2026 |
| Emerson Junior Mendoza Ventura | Planificación y facilitación de las 5 sesiones de validación inclusiva (AP3-01 a AP3-05), gestión de consentimientos informados, recolección de métricas (éxito, tiempos, SEQ) y consolidación del SUS. | Fichas de campo y registro de sesiones | 03/11/2026 – 05/11/2026 |

## Coevaluación del Grupo 5
Los cuatro integrantes han participado con alto compromiso y rigor metodológico en cada una de las fases del proyecto. Factor de contribución consensuado: 1,0 para todos los miembros.
