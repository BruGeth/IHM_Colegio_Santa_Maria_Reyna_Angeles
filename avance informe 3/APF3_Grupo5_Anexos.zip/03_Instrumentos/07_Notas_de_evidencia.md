# Interpretación de los registros técnicos

Las capturas y JSON corresponden a la revisión del 02/11/2026, salvo la línea base de participantes APF2 de octubre. No son sesiones APF3.

El bloque reviewKeyboard de V3-contacto-confirmacion.json documenta un intento inicial anterior al ajuste de contención del foco (inside=false). Se conserva el archivo original por integridad. La comprobación posterior del cambio está en V3-contacto-teclado.json (inside=true, foco Confirmar registro). La confirmación del primer JSON sí acredita guardado de demostración y región status polite. No se altera un resultado anterior para presentarlo como aprobado.

La captura de confirmación conserva la apariencia previa a la protección final contra doble envío. El código posterior deshabilita el envío tras guardar y ofrece Registrar otra consulta; su revalidación visual completa no se ejecutó en esta sesión. La matriz distingue implementación de verificación asistida.

Las capturas normales muestran un viewport, no el documento completo. Las fotografías con naturalWidth=0 fuera de la vista en screen-records.json pueden corresponder a carga diferida, no a enlaces rotos. Los valores de contraste se sustentan en colores registrados, CSS y JSON axe, incluso cuando el nodo está fuera de la captura normal.

El mapa de evidencias por hallazgo figura en Hallazgos del XLSX. Los resultados incomplete de axe exigen decisión manual. Una regla sin infracciones no demuestra cumplimiento de todos los criterios WCAG. No hay capturas Stark ni resultados de NVDA/VoiceOver en este paquete.

La automatización de ventanas se detuvo porque no pudo identificar con suficiente certeza la URL activa de Chrome. No se continuó con automatización de interfaz por otra vía. La autoría y comprobación posterior de documentos se realizó por herramientas de archivos.
