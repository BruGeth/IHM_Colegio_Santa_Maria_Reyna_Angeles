# Guía Rápida: Generar el Prototipo Accesible en Figma (APF3)

Este paquete contiene un **Figma Development Plugin** listo para usar que genera automáticamente las **6 páginas** completas del proyecto con marcos, componentes editables, variables de color (Estándar y Alto Contraste) y flujo de conexiones interactivas.

---

## Pasos para Generar las Páginas en Figma (Menos de 2 minutos)

### 1. Abre Figma Desktop
- Inicia sesión en la aplicación de escritorio de **Figma**.
- Crea o abre un archivo de diseño en blanco (**New design file**).

### 2. Importar el Plugin
1. Haz clic derecho en cualquier parte del lienzo en blanco (o abre el menú principal de Figma arriba a la izquierda).
2. Ve a **Plugins** > **Development** > **Import plugin from manifest...**
3. En la ventana del explorador, selecciona el archivo **`manifest.json`** ubicado en esta carpeta (`APF3_Grupo5_Figma_Importable`).
4. Figma confirmará que el plugin *"Santa María APF3 - Prototipo Accesible"* ha sido importado.

### 3. Ejecutar y Generar
1. Haz clic derecho en el lienzo > **Plugins** > **Development** > haz clic en **Santa María APF3 - Prototipo Accesible** (o pulsa **Run**).
2. Se abrirá una pequeña ventana.
3. Haz clic en el botón:  
   👉 **`⚡ Generar 6 Páginas en 1 Clic`**
4. En unos segundos, el plugin creará y organizará automáticamente las 6 páginas en el panel izquierdo de capas de Figma:
   - **`00 Leyenda y resumen`**: Alcance, rutas de demostración y leyenda de anotaciones.
   - **`01 Antes v2`**: Capturas reales de la versión anterior con registro de incidencias.
   - **`02 Después v3`**: 5 pantallas principales con flujo interactivo (Inicio, Primaria, Galería con modal, Contacto con validación de error, Revisión y Confirmación).
   - **`03 Kit accesible`**: Componentes Botón y Campo con estados (normal, hover, focus, error, disabled) y paleta institucional accesible.
   - **`04 Anotaciones`**: Mapa de navegación por teclado, orden de foco, roles ARIA y textos accesibles.
   - **`05 Contraste y texto`**: Pantallas en modo Alto Contraste y pruebas de legibilidad.

---

## Cómo Obtener el Enlace Público para la Entrega (Rúbrica UTP)
1. Con las páginas generadas, ve a la esquina superior derecha de Figma y pulsa el botón **Share** (Compartir).
2. En la ventana emergente, asegúrate de configurar el acceso en:  
   **"Anyone with the link can view"** (Cualquiera que tenga el vínculo puede ver).
3. Haz clic en **Copy link** (Copiar enlace).
4. *(Opcional pero recomendado)* Abre una pestaña en modo incógnito en tu navegador y pega el enlace para verificar que cualquier persona pueda ver el prototipo sin necesidad de iniciar sesión.
5. Pega este enlace en la portada del informe (`APF3_Grupo5_SantaMaria.docx` / `.pdf`) y en la diapositiva 1 de la presentación (`APF3_Grupo5_SantaMaria.pptx`).

---

## Archivos en esta Carpeta
- **`manifest.json`**: Archivo de configuración directo para importar el plugin en Figma.
- **`code.js`**: Lógica del plugin que construye las 6 páginas, nodos, variables y conexiones en Figma.
- **`ui.html`**: Interfaz visual optimizada con generación en 1 clic y recursos gráficos embebidos de alta eficiencia.
- **`SantaMaria_APF3_recursos.json`**: Versión ligera y optimizada de los recursos del proyecto (744 KB).
